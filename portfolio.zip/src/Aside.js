import { Link,Outlet } from "react-router-dom";
function Aside(){
    return(
        <>
        <div className="navbar">
            <aside>
                <ul className="nav">
                    <li className="nav-item"> <Link to='/About' className="active"><i class="fi fi-rs-user"></i>About</Link>
                    <li className="nav-item"><Link to='/Resume'><i class="fi fi-rs-document"></i>Resume</Link></li>
                    {/* <li className="nav-item"><Link to='/Experience'><i class="fi fi-rs-display-code"></i>Experience</Link></li> */}
                    <li className="nav-item"><Link to='/Work'><i class="fi fi-rs-briefcase"></i>Work</Link></li>
                    <li className="nav-item"><Link to='/Contact'><i class="fi fi-rs-address-book"></i>Contact</Link></li></li>
                </ul>
            </aside>
        </div></>
    )
}
export default Aside;