import {BrowserRouter as Router,Routes,Route} from 'react-router-dom';
import './App.css';
import React from 'react';
import Header from './Header';
import About from './About';
import Resume from './Resume';
import Experience from  './Experience';
import Work from './Work';
import Contact from './Contact';
import Aside from './Aside';

function App() {
  return (
    <>
    <div className='main_page'>
    <div className='container box'>
    <Router>
      <Header/>
      <div className='row main_content'>
        <div className='col-2'> 
        <Aside/>
        </div>
        <div className='col-10'> 
          <Routes>
            <Route path='/About' element={< About/>}/>
            <Route index element={<About/>}/>
            <Route path='/Resume' element={< Resume/>}/>
            <Route path='/Experience' element={< Experience/>}/>
            <Route path='/Work' element={< Work/>}/>
            <Route path='/Contact' element={< Contact/>}/>
          </Routes>
          </div>
        </div>
    </Router>
    
    </div>
    </div>
    </>
  );
}

export default App;